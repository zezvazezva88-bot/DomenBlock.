package com.domenblock

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
        }
        root.addView(TextView(this).apply {
            text = "DomenBlock\nრეკლამების ბლოკერის პროექტი"
            textSize = 25f
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "ეს არის საწყისი ვერსია. ამ ღილაკით იხსნება Android-ის Private DNS პარამეტრები. DNS ფილტრი შეიძლება ბლოკავდეს ბევრ რეკლამას აპებსა და ბრაუზერებში, მაგრამ არა ყველა რეკლამას და არა გარანტირებულად YouTube-ში."
            textSize = 16f
            setPadding(0, 24, 0, 24)
        })
        root.addView(Button(this).apply {
            text = "გახსენი Private DNS პარამეტრები"
            setOnClickListener {
                try { startActivity(Intent("android.settings.PRIVATE_DNS_SETTINGS")) }
                catch (_: Exception) { startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS)) }
            }
        })
        root.addView(TextView(this).apply {
            text = "შენიშვნა: ეს პროექტი ჯერ არ არის მზა რეკლამების დამბლოკავი და APK ფაილი ჯერ არ არის აგებული ან გამოცდილი."
            textSize = 14f
            setPadding(0, 24, 0, 0)
        })
        setContentView(root)
    }
}
